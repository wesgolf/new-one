# AI Agent Blueprint: Wes Artist Hub Recreation

## 1. Project Overview & Brand DNA
**Goal:** Create a premium, modern, high-end EDM Artist Hub.
**Persona:** Not a SaaS product. Not a generic portfolio. It must feel like a custom-designed visual experience similar to "Komi" but elevated for a music brand.
**Tech Stack:**
- **Framework:** React + Vite
- **Styling:** Tailwind CSS (Modern utility-first approach)
- **Animations:** Framer Motion (`motion/react`)
- **Icons:** FontAwesome (Brands + Solid)

---

## 2. Global Layout & Main Logic (`App.tsx`)
The main layout drives the core UX, specifically the **Sticky Logo Transition**.

### Key Functionality:
- **Sticky Logo Animation:** 
  - Use `useScroll` and `useTransform` from Framer Motion.
  - The logo ("WES.") starts at `scale: 6` and `y: 320` (centered in hero).
  - As the user scrolls (range: 0 to 400px), it shrinks to `scale: 1` and `y: 0` (top sticky position).
  - The logo should have `pointer-events-auto` and scroll to top on click.
- **Section Structure:** Hero -> Sticky Nav Container -> Featured Section -> Music -> Radio -> Shows -> Contact -> Footer.
- **Spacing:** High-density vertical spacing (`space-y-32`) between sections to provide "breathing room."
- **Selection Color:** Theme-consistent selection colors (`selection:bg-primary`).

---

## 3. Navigation Logic (Sticky Nav)
### Key Functionality:
- **Pill Design:** A floating, glassmorphism pill (`backdrop-blur-xl`, `bg-surface-container-low/80`).
- **Active State:** Use `layoutId="activeTab"` from Framer Motion for a spring-animated "slider" behind the active tab.
- **Scroll Tracking:** Use an effect with `window.scrollY` to update the active tab based on section offsets.
- **Smooth Scroll Offset:** Clicking a tab scrolls to the section with an offset (approx 140px) to account for the sticky header/nav.

---

## 4. Component Breakdown

### A. Hero Section (`Hero.tsx`)
- **Visual:** A large portrait image with "Blurred Edges" using a radial mask (`maskImage`).
- **Social Row:** evenly spaced icons (Instagram, Spotify, Apple, SoundCloud, TikTok, YouTube).
- **Animations:** Subtle staggered fades for icons and hover/tap scale effects.

### B. Featured Section (Stacked Cards)
- **Concept:** A "Komi-style" stack of cards directly under the hero.
- **Featured Release Card:**
  - **Horizontal on Desktop:** `flex-col sm:flex-row`.
  - **Artwork:** Compact square (`sm:w-48`) with a hover zoom effect.
  - **CTA:** Primary "Stream Now" pill + Secondary platform icons (Spotify/Apple/SC).
- **Secondary Cards:**
  - Compact horizontal cards (Radio Mix, Latest Reel).
  - Large colorful icons in rounded-2xl containers.
  - "CTA" text appears only on hover.

### C. Music Section (`PopularTracks.tsx`)
- High-end track list.
- Each row shows: Play Icon -> Title -> Stream Count -> Duration -> Share button.
- Subtle hover background changes to `surface-container-low`.

### D. Shows Section (`UpcomingShows.tsx`)
- This should initially represent a "No Shows" state.
- Use a clean centered empty-state: Ticket icon -> "No upcoming shows" text -> "Check back soon."

### E. Contact Block (`EmailCapture.tsx`)
- High-end newsletter signup.
- Centered card with rounded-3xl borders and subtle background glow (large blurred circles in corners).
- Clean inputs with `uppercase` placeholder text and wide character spacing.

---

## 5. Design Tokens & Styling
- **Backgrounds:** 深色 (Deep dark neutral backgrounds).
- **Colors:** Use a set of primary/secondary variants (e.g., Purple/Blue) but keep them muted and professional.
- **Borders:** Extremely subtle borders (`border-outline/5` or `border-outline/10`).
- **Rounded Corners:** Consistent high radii (`rounded-2xl` for small cards, `rounded-3xl` for main sections, `rounded-full` for pills).

---

## 6. Responsiveness Constraints
- **Mobile First:** Ensure all cards stack perfectly. Main content `max-w-2xl` to keep reading lines comfortable.
- **Horizontal Adaptation:** Release cards and track items should expand horizontally on landscape/desktop.
- **Touch Targets:** Buttons and social icons must be at least 44x44px for thumb-tapping.
